This is the text based version of Escape From Tarkov. This game is in the early, early works - and is a means of better understanding programming, and getting away from the day.

If you have fun, please let me know!

This game works on Windows only at the moment - unless you know how to run BAT files on Linux / MAC, I welcome you to play!

Thank you,

/u/ARasool
Twitter: @_BTCB_
Twitch: https://www.twitch.tv/BloodThirstyCheeseBurger